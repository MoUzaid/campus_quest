// const express = require("express");
// const router = express.Router();

// const {
//   getMyFacultyActivities
// } = require("../controllers/FacultyActivityController");

// const authFaculty = require("../middlewares/authFaculty");

// router.get(
//   "/activities",
//   authFaculty,
//   getMyFacultyActivities
// );

// module.exports = router;
